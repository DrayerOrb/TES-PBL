document.getElementById('requestFriendForm').onsubmit = async function(event) {
    event.preventDefault();
    const username = document.getElementById('friendUsername').value;
    const publicKey = document.getElementById('friendPublicKey').value;

    try {
        const response = await fetch('/add_friend', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, public_key: publicKey })
        });
        const result = await response.json();
        alert(result.status);

        document.getElementById('friendUsername').value = '';
        document.getElementById('friendPublicKey').value = '';

        fetchFriendRequests(); 
    } catch (error) {
        console.error('Error sending friend request:', error);
        alert('Terjadi kesalahan saat mengirim permintaan pertemanan.');
    }
};

async function respondToRequest(requestId, response) {
    console.log('Request ID:', requestId); 
    console.log('Response:', response); 

    try {
        const res = await fetch('/respond_friend_request', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ request_id: requestId, response }) 
        });
        const result = await res.json();
        alert(result.status);
        fetchFriendRequests(); 
    } catch (error) {
        console.error('Error responding to friend request:', error);
        alert('Terjadi kesalahan saat merespons permintaan pertemanan.');
    }
}

async function fetchFriendRequests() {
    try {
        const response = await fetch('/friend_requests');
        const requests = await response.json();
        const requestsContainer = document.getElementById('requests');
        requestsContainer.innerHTML = '';

        requests.forEach(request => {
            const requestElement = document.createElement('div');
            requestElement.className = 'request';
            requestElement.innerHTML = `
                <p>${request.username} mengirim permintaan pertemanan.</p>
                <button onclick="respondToRequest(${request.id}, 'accept')">Terima</button>
                <button onclick="respondToRequest(${request.id}, 'reject')">Tolak</button>
            `;
            requestsContainer.appendChild(requestElement);
        });
    } catch (error) {
        console.error('Error fetching friend requests:', error);
        alert('Terjadi kesalahan saat mengambil permintaan pertemanan.');
    }
}

async function fetchFriends() {
    try {
        const response = await fetch('/friends');
        const friends = await response.json();
        const friendsContainer = document.getElementById('friendsList');
        friendsContainer.innerHTML = '';

        friends.forEach(friend => {
            const friendElement = document.createElement('div');
            friendElement.innerHTML = `
                <p>
                    <a href="/chat_page?friend_id=${friend.id}" class="friend-link">${friend.username}</a>
                </p>
            `;
            friendsContainer.appendChild(friendElement);
        });
    } catch (error) {
        console.error('Error fetching friends:', error);
        alert('Terjadi kesalahan saat mengambil daftar teman.');
    }
}

fetchFriendRequests(); 
fetchFriends(); 