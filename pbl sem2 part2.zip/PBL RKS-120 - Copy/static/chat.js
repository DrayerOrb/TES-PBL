const socket = io();
let userId = sessionStorage.getItem('user_id');
let urlParams = new URLSearchParams(window.location.search);
let friendId = urlParams.get('friend_id');

if (!userId) {
    alert('Anda harus login terlebih dahulu.');
    window.location.href = '/login_page';
}

// Gabung ke room chat
const room = `room_${Math.min(userId, friendId)}_${Math.max(userId, friendId)}`;
socket.emit('join', { room });

socket.on('receive_message', data => {
    if (parseInt(data.sender_id) !== parseInt(friendId) && parseInt(data.sender_id) !== parseInt(userId)) return;

    const messagesDiv = document.getElementById('messages');
    const msgElement = document.createElement('div');
    msgElement.className = 'message';

    if (data.sender_id == userId) {
        msgElement.classList.add('sent-message');
        msgElement.innerHTML = `<strong>Anda:</strong> ${data.message} <em>${new Date().toLocaleString()}</em>`;
    } else {
        msgElement.classList.add('received-message');
        msgElement.innerHTML = `<strong>Teman:</strong> ${data.message} <em>${new Date().toLocaleString()}</em>`;
    }

    messagesDiv.appendChild(msgElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
});

async function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const message = messageInput.value.trim();
    const friendId = document.getElementById('friendId').value;

    if (!message || !friendId) {
        alert("Pesan atau ID teman tidak valid.");
        return;
    }

    try {
        const response = await fetch('/send_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',  // Pastikan mengirim cookies untuk session
            body: JSON.stringify({ friend_id: friendId, message: message })
        });

        const result = await response.json();
        console.log(result);  // Debugging response dari server

        if (response.ok) {
            // Bersihkan input dan update UI jika berhasil
            messageInput.value = '';
            alert('Pesan berhasil terkirim!');
        } else {
            alert(result.status || 'Gagal mengirim pesan');
        }
    } catch (err) {
        console.error('Terjadi kesalahan:', err);
        alert('Terjadi kesalahan saat mengirim pesan');
    }
}

