const socket = io();
let userId = sessionStorage.getItem('user_id');
let privateKey = sessionStorage.getItem('private_key');
let friendId = new URLSearchParams(window.location.search).get('friend_id'); 

if (!userId) {
    alert('Anda harus login terlebih dahulu.');
    window.location.href = '/login_page';
}

document.getElementById('messageForm').onsubmit = async function(event) {
    event.preventDefault();
    const message = document.getElementById('messageInput').value; 
    const receiverPublicKey = document.getElementById('receiver_public_key').value; 

    if (!message || !receiverPublicKey) {
        alert('Pesan dan kunci publik penerima harus diisi.');
        return;
    }

    socket.emit('send_message', { sender_id: userId, receiver_public_key: receiverPublicKey, message: message });
    
    const messagesDiv = document.getElementById('messages');
    const timestamp = new Date().toLocaleString();
    const msgElement = document.createElement('div');
    msgElement.className = 'message sent-message'; 
    msgElement.innerHTML = `<strong>Anda:</strong> ${message} <em>${timestamp}</em>`;
    messagesDiv.appendChild(msgElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    document.getElementById('messageInput').value = ''; 
};

socket.on('receive_message', function(data) {
    const messagesDiv = document.getElementById('messages');
    const timestamp = new Date().toLocaleString();
    const msgElement = document.createElement('div');
    msgElement.className = 'message received-message'; 
    msgElement.innerHTML = `<strong>Pengirim ID ${data.sender_id}:</strong> ${data.message} <em>${timestamp}</em>`;
    messagesDiv.appendChild(msgElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
});

document.getElementById('logoutButton').onclick = async function() {
    const response = await fetch('/logout', {
        method: 'POST'
    });
    const result = await response.json();
    alert(result.status);
    sessionStorage.clear();
    window.location.href = '/';
};

async function sendMessage() {
    const message = document.getElementById('messageInput').value;
    if (!message) {
        alert('Pesan tidak boleh kosong!');
        return;
    }

    try {
        const response = await fetch('/send_message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ friend_id: friendId, message: message })
        });

        const result = await response.json();
        alert(result.status);

        const messagesDiv = document.getElementById('messages');
        const timestamp = new Date().toLocaleString();
        const msgElement = document.createElement('div');
        msgElement.className = 'message sent-message'; 
        msgElement.innerHTML = `<strong>Anda:</strong> ${message} <em>${timestamp}</em>`;
        messagesDiv.appendChild(msgElement);
        messagesDiv.scrollTop = messagesDiv.scrollHeight; 

        document.getElementById('messageInput').value = ''; 
    } catch (error) {
        console.error('Error sending message:', error);
        alert('Terjadi kesalahan saat mengirim pesan.');
    }
}

async function fetchMessages() {
    const response = await fetch(`/get_messages/${friendId}`);
    if (response.ok) {
        const messages = await response.json();
        const messagesContainer = document.getElementById('messages');
        messagesContainer.innerHTML = '';

        messages.forEach(msg => {
            const msgElement = document.createElement('div');
            msgElement.className = 'message';
            if (msg.sender_id == userId) {
                msgElement.classList.add('sent-message'); 
                msgElement.innerHTML = `<strong>Anda:</strong> ${msg.content} <em>${new Date(msg.timestamp).toLocaleString()}</em>`;
            } else {
                msgElement.classList.add('received-message'); 
                msgElement.innerHTML = `<strong>Pengirim ID ${msg.sender_id}:</strong> ${msg.content} <em>${new Date(msg.timestamp).toLocaleString()}</em>`; 
            }
            messagesContainer.appendChild(msgElement);
        });
    } else {
        alert('Gagal mendapatkan pesan.');
    }
}

setInterval(fetchMessages, 5000); 