const socket = io();
let userId = sessionStorage.getItem('user_id');
let urlParams = new URLSearchParams(window.location.search);
let friendId = urlParams.get('friend_id');

if (!userId) {
    alert('Anda harus login terlebih dahulu.');
    window.location.href = '/login_page';
}

// Bergabung dengan room chat Socket.IO
socket.emit('join', { friend_id: friendId });

socket.on('receive_message', data => {
    if (parseInt(data.sender_id) !== parseInt(friendId) && parseInt(data.sender_id) !== parseInt(userId)) return;

    const messagesDiv = document.getElementById('messages');
    const msgElement = document.createElement('div');
    msgElement.className = 'message';

    // Jika pengirim adalah user sendiri
    if (data.sender_id == userId) {
        msgElement.classList.add('sent-message');
        msgElement.innerHTML = `<strong>Anda:</strong> ${data.message} <em>${new Date().toLocaleString()}</em>`;
    } else {
        // Pesan diterima dari teman
        msgElement.classList.add('received-message');
        msgElement.innerHTML = `<strong>Teman:</strong> ${data.message} <em>${new Date().toLocaleString()}</em>`;
    }
    messagesDiv.appendChild(msgElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
});

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();

    if (!message) {
        alert('Pesan tidak boleh kosong!');
        return;
    }

    try {
        const response = await fetch('/send_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ friend_id: friendId, message })
        });

        const result = await response.json();

        if (!response.ok) {
            alert(result.status);
            return;
        }

        // Kirim pesan ke server via Socket.IO untuk real-time
        socket.emit('receive_message', { sender_id: userId, message });

        // Tampilkan pesan di UI
        const messagesDiv = document.getElementById('messages');
        const msgElement = document.createElement('div');
        msgElement.className = 'message sent-message';
        msgElement.innerHTML = `<strong>Anda:</strong> ${message} <em>${new Date().toLocaleString()}</em>`;
        messagesDiv.appendChild(msgElement);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;

        input.value = '';
    } catch (err) {
        console.error('Error mengirim pesan:', err);
        alert('Terjadi kesalahan saat mengirim pesan');
    }
}

async function fetchMessages() {
    try {
        const response = await fetch(`/get_messages/${friendId}`);
        if (!response.ok) throw new Error('Gagal mengambil pesan');

        const messages = await response.json();
        const messagesDiv = document.getElementById('messages');
        messagesDiv.innerHTML = '';

        messages.forEach(msg => {
            const msgElement = document.createElement('div');
            msgElement.className = 'message';

            if (msg.sender_id == userId) {
                msgElement.classList.add('sent-message');
                msgElement.innerHTML = `<strong>Anda:</strong> ${msg.message} <em>${new Date(msg.timestamp).toLocaleString()}</em>`;
            } else {
                msgElement.classList.add('received-message');
                msgElement.innerHTML = `<strong>Teman:</strong> ${msg.message} <em>${new Date(msg.timestamp).toLocaleString()}</em>`;
            }

            messagesDiv.appendChild(msgElement);
        });

        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    } catch (err) {
        console.error(err);
        alert('Gagal mengambil pesan');
    }
}

setInterval(fetchMessages, 3000);

document.getElementById('logoutButton').onclick = async function() {
    try {
        const res = await fetch('/logout', { method: 'POST' });
        const result = await res.json();
        alert(result.status);
        sessionStorage.clear();
        window.location.href = '/login_page';
    } catch (err) {
        console.error(err);
        alert('Terjadi kesalahan saat logout');
    }
};
