document.getElementById('registerForm').onsubmit = async function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });
    const result = await response.json();
    alert(result.status);
    if (response.ok) {
        document.getElementById('publicKey').innerText = result.public_key; 
        document.getElementById('privateKey').innerText = result.private_key; 
        document.querySelector('.key-container').style.display = 'block'; 
    }
};

function copyToClipboard(id) {
    const text = document.getElementById(id).innerText;
    navigator.clipboard.writeText(text).then(() => {
        alert('Kunci telah disalin ke clipboard!');
    }).catch(err => {
        console.error('Gagal menyalin: ', err);
    });
}