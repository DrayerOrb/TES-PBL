from flask import Flask, request, jsonify, render_template, session
from flask_mysqldb import MySQL
from flask_socketio import SocketIO
from crypto import generate_keys, encrypt_message, decrypt_message
import logging
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  
app.config['MYSQL_PASSWORD'] = ''  
app.config['MYSQL_DB'] = 'chat_app'

mysql = MySQL(app)
socketio = SocketIO(app)

logging.basicConfig(level=logging.INFO)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register_page')
def register_page():
    return render_template('register.html')

@app.route('/login_page')
def login_page():
    return render_template('login.html')

@app.route('/request_friend_page')
def request_friend_page():
    return render_template('request_friend.html')

@app.route('/chat_page')
def chat_page():
    friend_id = request.args.get('friend_id')  
    return render_template('chat.html', friend_id=friend_id)  

@app.route('/register', methods=['POST'])
def register():
    username = request.json['username']
    password = request.json['password']
    logging.info(f'Mencoba mendaftar pengguna: {username}')
    
    if len(password) < 8:
        return jsonify({'status': 'Password harus minimal 8 karakter'}), 400

    private_key, public_key = generate_keys()
    hashed_password = generate_password_hash(password)
    logging.info(f'Password yang di-hash untuk {username}: {hashed_password}')
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    existing_user = cursor.fetchone()
    
    if existing_user:
        return jsonify({'status': 'Username sudah terdaftar'}), 400

    cursor.execute("INSERT INTO users (username, public_key, private_key, password) VALUES (%s, %s, %s, %s)", (username, public_key, private_key, hashed_password))
    mysql.connection.commit()
    cursor.close()
    
    return jsonify({'status': 'Pengguna terdaftar', 'public_key': public_key.decode(), 'private_key': private_key.decode()})

@app.route('/login', methods=['POST'])
def login():
    username = request.json['username']
    password = request.json['password']  
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, password, private_key FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    
    logging.info(f'User  yang ditemukan: {user}')  
    
    if user and check_password_hash(user[1], password):  
        session['user_id'] = user[0]
        session['private_key'] = user[2]
        return jsonify({'status': 'Login berhasil', 'user_id': user[0]})
    else:
        return jsonify({'status': 'Pengguna tidak ditemukan atau password salah'}), 404

@app.route('/add_friend', methods=['POST'])
def add_friend():
    data = request.json
    username = data['username']
    public_key = data['public_key']
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
    friend = cursor.fetchone()
    
    if friend:
        friend_id = friend[0]
        sender_id = session['user_id']
        cursor.execute("INSERT INTO friend_requests (sender_id, receiver_id) VALUES (%s, %s)", (sender_id, friend_id))
        mysql.connection.commit()
        cursor.close()
        return jsonify({'status': 'Permintaan pertemanan berhasil dikirim'})
    else:
        return jsonify({'status': 'Pengguna tidak ditemukan'}), 404

@app.route('/friend_requests', methods=['GET'])
def get_friend_requests():
    user_id = session['user_id']
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT fr.id, u.username 
        FROM friend_requests fr 
        JOIN users u ON fr.sender_id = u.id 
        WHERE fr.receiver_id = %s AND fr.status = 'pending'
    """, (user_id ,))  
    requests = cursor.fetchall()
    cursor.close()
    
    logging.info(f'Permintaan pertemanan untuk pengguna {user_id}: {requests}')  
    return jsonify([{'id': req[0], 'username': req[1]} for req in requests])  

@app.route('/respond_friend_request', methods=['POST'])
def respond_friend_request():
    data = request.json
    request_id = data.get('request_id')  
    response = data.get('response')  
    
    if request_id is None or response is None:
        return jsonify({'status': 'Data tidak lengkap'}), 400  

    cursor = mysql.connection.cursor()
    if response == 'accept':
        cursor.execute("UPDATE friend_requests SET status = 'accepted' WHERE id = %s", (request_id,))
    else:
        cursor.execute("UPDATE friend_requests SET status = 'rejected' WHERE id = %s", (request_id,))
    
    mysql.connection.commit()
    cursor.close()
    
    return jsonify({'status': 'Permintaan pertemanan telah diproses'})

@app.route('/friends', methods=['GET'])
def get_friends():
    user_id = session['user_id']
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT u.id, u.username FROM users u
        JOIN friend_requests fr ON (u.id = fr.receiver_id OR u.id = fr.sender_id)
        WHERE (fr.sender_id = %s OR fr.receiver_id = %s) AND fr.status = 'accepted'
    """, (user_id, user_id))
    friends = cursor.fetchall()
    cursor.close()
    
    return jsonify([{'id': friend[0], 'username': friend[1]} for friend in friends])

@app.route('/get_friend_username/<int:friend_id>', methods=['GET'])
def get_friend_username(friend_id):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT username FROM users WHERE id = %s", (friend_id,))
    friend = cursor.fetchone()
    cursor.close()
    
    if friend:
        return jsonify({'username': friend[0]})
    else:
        return jsonify({'status': 'Pengguna tidak ditemukan'}), 404
    
@app.route('/send_message', methods=['POST'])
def send_message():
    data = request.json
    friend_id = data['friend_id']
    message = data['message']
    sender_id = session['user_id']

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT public_key FROM users WHERE id = %s", (friend_id,))
    receiver = cursor.fetchone()
    cursor.close()

    if receiver:
        receiver_public_key = receiver[0]
        encrypted_message = encrypt_message(message, receiver_public_key)

        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO messages (sender_id, receiver_id, message, timestamp) VALUES (%s, %s, %s, %s)", (sender_id, friend_id, encrypted_message, datetime.now()))
        mysql.connection.commit()
        cursor.close()

        socketio.emit('receive_message', {'sender_id': sender_id, 'message': message}, room=friend_id)
        return jsonify({'status': 'Pesan berhasil dikirim', 'message': message}), 200
    else:
        return jsonify({'status': 'Penerima tidak ditemukan'}), 404
        
@app.route('/get_messages/<int:friend_id>', methods=['GET'])
def get_messages(friend_id):
    user_id = session['user_id']
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT sender_id, message, timestamp FROM messages 
        WHERE (sender_id = %s AND receiver_id = %s) OR (sender_id = %s AND receiver_id = %s) 
        ORDER BY timestamp
    """, (user_id, friend_id, friend_id, user_id)) 
    messages = cursor.fetchall()
    cursor.close()

    decrypted_messages = []
    private_key = session.get('private_key')
    for message in messages:
        try:
            decrypted_message = decrypt_message(message[1], private_key) 
            decrypted_messages.append({
                'sender_id': message[0], 
                'content': decrypted_message,
                'timestamp': message[2]
            })
        except Exception as e:
            logging.error(f"Error decrypting message: {e}")
            continue  

    return jsonify(decrypted_messages)

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'status': 'Logout berhasil'})

@socketio.on('send_message')
def handle_send_message(data):
    sender_id = data['sender_id']
    receiver_public_key = data['receiver_public_key']
    message = data['message']

    encrypted_message = encrypt_message(message, receiver_public_key)

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE public_key = %s", (receiver_public_key,))
    receiver = cursor.fetchone()
    
    if receiver:
        receiver_id = receiver[0]
        cursor.execute("INSERT INTO messages (sender_id, receiver_id, message) VALUES (%s, %s, %s)", (sender_id, receiver_id, encrypted_message))
        mysql.connection.commit()

        socketio.emit('receive_message', {'sender_id': sender_id, 'message': message}, room=receiver_id)
    else:
        return jsonify({'status': 'Penerima tidak ditemukan'}), 404

@app.route('/receive/<int:user_id>', methods=['GET'])
def receive_messages(user_id):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM messages WHERE receiver_id = %s", (user_id,))
    messages = cursor.fetchall()
    cursor.close()
    
    decrypted_messages = []
    private_key = session.get('private_key')
    for message in messages:
        decrypted_message = decrypt_message(message[2], private_key)  
        decrypted_messages.append({
            'sender_id': message[1],
            'message': decrypted_message,
            'timestamp': message[3]  
        })
    
    return jsonify(decrypted_messages)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)