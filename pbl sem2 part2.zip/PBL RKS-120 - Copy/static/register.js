document.getElementById('registerForm').onsubmit = async function(event) {
    event.preventDefault();
    const username = document.querySelector('input[name="username"]').value.trim();
    const password = document.querySelector('input[name="password"]').value;

    if (!username || !password) {
        alert('Username dan password tidak boleh kosong');
        return;
    }

    if (password.length < 8) {
        alert('Password harus minimal 8 karakter');
        return;
    }

    try {
        const response = await fetch('/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const result = await response.json();
        alert(result.status);
        if (response.ok) {
            window.location.href = '/login_page';
        }
    } catch (err) {
        console.error('Error registrasi:', err);
        alert('Terjadi kesalahan saat registrasi');
    }
};
