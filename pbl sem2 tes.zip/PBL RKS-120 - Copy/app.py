import hashlib
from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_mysqldb import MySQL
from flask_socketio import SocketIO, emit, join_room, leave_room
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MySQL config - adjust as needed
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'chat_app'

mysql = MySQL(app)
socketio = SocketIO(app, manage_session=False)

# Konstanta kunci substitution cipher (reversed alphabet)
SUBSTITUTION_KEY = 'zyxwvutsrqponmlkjihgfedcba'
ALPHABET = 'abcdefghijklmnopqrstuvwxyz'

def hash_password(password: str) -> str:
    """Hash password with SHA-256 plus salt 'wzregw' as requested."""
    salt = 'wzregw'
    return hashlib.sha256((salt + password).encode()).hexdigest()

def substitution_cipher_encrypt(message: str, key: str) -> str:
    encrypted = ''
    message = message.lower()
    for ch in message:
        if ch in ALPHABET:
            idx = ALPHABET.index(ch)
            encrypted += key[idx]
        else:
            encrypted += ch
    return encrypted

def substitution_cipher_decrypt(message: str, key: str) -> str:
    decrypted = ''
    for ch in message:
        if ch in key:
            idx = key.index(ch)
            decrypted += ALPHABET[idx]
        else:
            decrypted += ch
    return decrypted

@app.route('/')
def index():
    # If logged in redirect to friend page, else show index
    if 'user_id' in session:
        return redirect(url_for('request_friend_page'))
    return render_template('index.html')

@app.route('/register_page')
def register_page():
    if 'user_id' in session:
        return redirect(url_for('request_friend_page'))
    return render_template('register.html')

@app.route('/login_page')
def login_page():
    if 'user_id' in session:
        return redirect(url_for('request_friend_page'))
    return render_template('login.html')

@app.route('/request_friend_page')
def request_friend_page():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))
    return render_template('request_friend.html')

@app.route('/chat_page')
def chat_page():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))
    friend_id = request.args.get('friend_id')
    if not friend_id:
        return redirect(url_for('request_friend_page'))
    return render_template('chat.html', friend_id=friend_id)

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not username or not password:
        return jsonify({'status': 'Username dan password harus diisi'}), 400
    if len(password) < 8:
        return jsonify({'status': 'Password harus minimal 8 karakter'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
    if cursor.fetchone() is not None:
        cursor.close()
        return jsonify({'status': 'Username sudah terdaftar'}), 400

    hashed_pw = hash_password(password)
    cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_pw))
    mysql.connection.commit()
    cursor.close()

    return jsonify({'status': 'Registrasi berhasil. Silakan login.'})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not username or not password:
        return jsonify({'status': 'Username dan password harus diisi'}), 400

    hashed_pw = hash_password(password)
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, password FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()

    if user and user[1] == hashed_pw:
        session['user_id'] = user[0]
        session['username'] = username
        return jsonify({'status': 'Login berhasil', 'user_id': user[0]})
    else:
        return jsonify({'status': 'Username atau password salah'}), 401

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'status': 'Logout berhasil'})

@app.route('/add_friend', methods=['POST'])
def add_friend():
    if 'user_id' not in session:
        return jsonify({'status': 'Anda harus login'}), 401

    data = request.json
    friend_username = data.get('username', '').strip()

    if not friend_username:
        return jsonify({'status': 'Username teman harus diisi'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id FROM users WHERE username = %s", (friend_username,))
    friend = cursor.fetchone()

    if not friend:
        cursor.close()
        return jsonify({'status': 'Pengguna tidak ditemukan'}), 404

    sender_id = session['user_id']
    receiver_id = friend[0]

    # Cek sudah ada permintaan pertemanan aktif atau sudah jadi teman
    cursor.execute("""
        SELECT id FROM friend_requests
        WHERE (sender_id = %s AND receiver_id = %s) OR (sender_id = %s AND receiver_id = %s)
          AND status = 'accepted'
    """, (sender_id, receiver_id, receiver_id, sender_id))
    if cursor.fetchone():
        cursor.close()
        return jsonify({'status': 'Anda sudah berteman dengan pengguna ini'}), 400

    cursor.execute("""
        SELECT id FROM friend_requests
        WHERE sender_id = %s AND receiver_id = %s AND status = 'pending'
    """, (sender_id, receiver_id))
    if cursor.fetchone():
        cursor.close()
        return jsonify({'status': 'Permintaan pertemanan sudah dikirim'}), 400

    cursor.execute("INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (%s, %s, 'pending')", (sender_id, receiver_id))
    mysql.connection.commit()
    cursor.close()

    return jsonify({'status': 'Permintaan pertemanan terkirim'})

@app.route('/friend_requests')
def friend_requests():
    if 'user_id' not in session:
        return jsonify({'status': 'Anda harus login'}), 401

    user_id = session['user_id']

    cursor = mysql.connection.cursor()
    # Ambil permintaan pertemanan yang masuk untuk user yang belum diproses (pending)
    cursor.execute("""
        SELECT fr.id, u.username
        FROM friend_requests fr
        JOIN users u ON fr.sender_id = u.id
        WHERE fr.receiver_id = %s AND fr.status = 'pending'
    """, (user_id,))
    requests = cursor.fetchall()
    cursor.close()

    data = [{'id': r[0], 'username': r[1]} for r in requests]
    return jsonify(data)

@app.route('/respond_friend_request', methods=['POST'])
def respond_friend_request():
    if 'user_id' not in session:
        return jsonify({'status': 'Anda harus login'}), 401

    data = request.json
    request_id = data.get('request_id')
    response = data.get('response')

    if not request_id or response not in ['accept', 'reject']:
        return jsonify({'status': 'Data tidak lengkap atau tidak valid'}), 400

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT receiver_id FROM friend_requests WHERE id = %s", (request_id,))
    req = cursor.fetchone()

    if not req or req[0] != session['user_id']:
        cursor.close()
        return jsonify({'status': 'Permintaan tidak ditemukan atau bukan milik Anda'}), 404

    new_status = 'accepted' if response == 'accept' else 'rejected'

    cursor.execute("UPDATE friend_requests SET status = %s WHERE id = %s", (new_status, request_id))
    mysql.connection.commit()
    cursor.close()

    return jsonify({'status': f'Permintaan pertemanan {new_status}'})

@app.route('/friends')
def friends():
    if 'user_id' not in session:
        return jsonify({'status': 'Anda harus login'}), 401

    user_id = session['user_id']
    cursor = mysql.connection.cursor()
    # Ambil teman di mana status friend_requests accepted dan user_id ada di sender atau receiver
    cursor.execute("""
        SELECT u.id, u.username
        FROM users u
        JOIN friend_requests fr ON ( (fr.sender_id = %s AND fr.receiver_id = u.id) OR (fr.receiver_id = %s AND fr.sender_id = u.id) )
        WHERE fr.status = 'accepted'
    """, (user_id, user_id))
    friends = cursor.fetchall()
    cursor.close()

    data = [{'id': f[0], 'username': f[1]} for f in friends]
    return jsonify(data)

@app.route('/send_message', methods=['POST'])
def send_message():
    if 'user_id' not in session:
        return jsonify({'status': 'Anda harus login'}), 401

    data = request.json
    friend_id = data.get('friend_id')
    message = data.get('message', '').strip()

    if not friend_id or not message:
        return jsonify({'status': 'Data pesan tidak lengkap'}), 400

    # Pastikan friend_id adalah teman
    user_id = session['user_id']
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT id FROM friend_requests
        WHERE ((sender_id = %s AND receiver_id = %s) OR (sender_id = %s AND receiver_id = %s)) AND status = 'accepted'
    """, (user_id, friend_id, friend_id, user_id))
    if not cursor.fetchone():
        cursor.close()
        return jsonify({'status': 'Anda hanya bisa mengirim pesan ke teman'}), 403

    encrypted_msg = substitution_cipher_encrypt(message, SUBSTITUTION_KEY)
    cursor.execute("INSERT INTO messages (sender_id, receiver_id, message) VALUES (%s, %s, %s)", (user_id, friend_id, encrypted_msg))
    mysql.connection.commit()
    cursor.close()

    # Emit via Socket.IO room for real-time update
    room = get_room_name(user_id, friend_id)
    socketio.emit('receive_message', {'sender_id': user_id, 'message': message}, room=room)

    return jsonify({'status': 'Pesan terkirim'})

@app.route('/get_messages/<friend_id>', methods=['GET'])
def get_messages(friend_id):
    if 'user_id' not in session:
        return jsonify({'status': 'Anda harus login'}), 401

    user_id = session['user_id']

    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT sender_id, message, timestamp
        FROM messages
        WHERE (sender_id = %s AND receiver_id = %s) OR (sender_id = %s AND receiver_id = %s)
        ORDER BY timestamp ASC
    """, (user_id, friend_id, friend_id, user_id))
    rows = cursor.fetchall()
    cursor.close()

    decrypted_msgs = []
    for row in rows:
        decrypted_msg = substitution_cipher_decrypt(row[1], SUBSTITUTION_KEY)
        decrypted_msgs.append({'sender_id': row[0], 'message': decrypted_msg, 'timestamp': row[2].strftime('%Y-%m-%d %H:%M:%S')})

    return jsonify(decrypted_msgs)

# Socket.IO events
@socketio.on('join')
def on_join(data):
    user_id = session.get('user_id')
    friend_id = data.get('friend_id')
    if user_id and friend_id:
        room = get_room_name(user_id, friend_id)
        join_room(room)

@socketio.on('leave')
def on_leave(data):
    user_id = session.get('user_id')
    friend_id = data.get('friend_id')
    if user_id and friend_id:
        room = get_room_name(user_id, friend_id)
        leave_room(room)

def get_room_name(user1, user2):
    sorted_ids = sorted([str(user1), str(user2)])
    return 'room_' + '_'.join(sorted_ids)

# Run app
if __name__ == '__main__':
    socketio.run(app, debug=True)
